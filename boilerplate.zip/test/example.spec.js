/**
 * @author rik
 */
describe(`example test`, () => {

  it(`should test some stuff`, (done) => {
    done();
  });

});