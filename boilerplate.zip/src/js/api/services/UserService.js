/**
 * @author rik
 */
const UserService = {
  someMethod(model) {

  }
};

export default UserService;