/**
 * @author rik
 */
import test from '../../../tags/test.tag';

const TestStaticView = {
  tag: test,
  holder: 'body'
};

export default TestStaticView;