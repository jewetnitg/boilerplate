/**
 * @author rik
 */
function alwaysAllow(req) {
  return Promise.resolve();
}

export default alwaysAllow;