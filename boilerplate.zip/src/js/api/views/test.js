/**
 * @author rik
 */
import test from '../../../tags/user-details.tag';

const TestView = {
  tag: test,
  holder: 'body'
};

export default TestView;