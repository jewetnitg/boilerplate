/**
 * @author rik
 */
import tag from '../../../tags/user-details-2.tag';

const testStaticView = {
  tag,
  holder: '.static'
};

export default testStaticView;