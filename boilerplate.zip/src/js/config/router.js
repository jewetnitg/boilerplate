/**
 * @author rik
 */

const routerConfig = {
  defaultRoute: '/users',
  pushState: true
};

export default routerConfig;