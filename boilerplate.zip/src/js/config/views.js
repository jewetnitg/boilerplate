/**
 * @author rik
 */
const viewConfig = {};

export default viewConfig;