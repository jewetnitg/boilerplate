/**
 * @author rik
 */

const connectionConfig = {
  'local-xhr': {
    url: 'http://192.168.0.7:1337',
    adapter: 'XHR'
  }
};

export default connectionConfig;