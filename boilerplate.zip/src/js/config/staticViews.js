/**
 * @author rik
 */
const staticViewsConfig = {};

export default staticViewsConfig;