const en_GB = {

  words: {
    general: {
      "yes": "yes"
    }
  }

};

export default en_GB;