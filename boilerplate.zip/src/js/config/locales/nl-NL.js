const nl_NL = {

  words: {
    general: {
      "yes": "ja"
    }
  }

};

export default nl_NL;