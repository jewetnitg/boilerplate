const devEnv = {
  config: {},
  api: {},
  components: {}
};

export default devEnv;