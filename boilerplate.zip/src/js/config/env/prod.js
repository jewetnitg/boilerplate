const prodEnv = {
  config: {},
  api: {},
  components: {}
};

export default prodEnv;