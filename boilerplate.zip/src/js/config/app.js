/**
 * @author rik
 */

const appConfig = {

  defaultLocale: 'en-GB',
  defaultConnection: 'local-xhr'

};

export default appConfig;