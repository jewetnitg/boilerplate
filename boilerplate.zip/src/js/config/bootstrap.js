/**
 * @author rik
 */

function bootstrap() {
  return Promise.resolve();
}

export default bootstrap;