# frntnd-communicator

Documentation available at http://jewetnitg.github.io/frntnd-communicator/
