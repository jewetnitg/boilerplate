module.exports = {
  entries: './src/js/main.js',
  transform: [
    "riotify"
  ],
  debug: true
};