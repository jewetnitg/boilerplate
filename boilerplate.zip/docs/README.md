TODOs
=====
* Create a phantomJs node server that serves the evaluated applications HTML, so the application can easily be made SEO friendly
* Create CLI to generate a boilerplate, models, view etc. sails like CLI generator, use yeoman for this